"""
LaTeX → Word 公式渲染器
用法:
    from renderer import render_latex_to_word

    formulas = [
        (r"\\frac{a}{b}", "分式"),
    ]
    render_latex_to_word(formulas, "output.docx")

    # 行内公式段落
    add_inline_paragraph(doc, [
        "若函数 ", "f", " 在 ", "[a,b]", " 上连续，且 ",
        r"f(a) \\cdot f(b) < 0", "，则存在零点。"
    ])

或命令行:
    python renderer.py input.txt output.docx
"""
import sys
from latex2mathml import converter as latex2mathml_converter
from docx import Document
from lxml import etree

MML2OMML_PATH = r"C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL"

# 预加载 XSL 转换器
_xslt_doc = etree.parse(MML2OMML_PATH)
_xslt_transform = etree.XSLT(_xslt_doc)

def latex_to_omml(latex: str) -> etree._Element:
    """LaTeX 字符串 → OMML XML 元素"""
    mathml_str = latex2mathml_converter.convert(latex)
    mathml = etree.fromstring(mathml_str.encode('utf-8'))
    omml_result = _xslt_transform(mathml)
    return omml_result.getroot()


def is_latex(text: str) -> bool:
    """简单判断一段文本是否包含 LaTeX 命令（非纯文字）"""
    import re
    return bool(re.search(r'\\|[\^_{]', text))


def add_inline_paragraph(
    doc: 'Document',
    segments: list,
    style: str = 'Normal',
    font_size: int = None,
    font_name: str = None
):
    """
    创建含行内公式的段落。

    Args:
        doc: python-docx Document 对象
        segments: 字符串列表，普通文字和 LaTeX 公式交替
                  纯文字直接渲染为文本，LaTeX（含 \\ ^ _ { }）渲染为行内公式
        style: 段落样式名，默认 'Normal'
        font_size: 字体大小（pt），默认继承样式
        font_name: 字体名

    Example:
        doc = Document()
        add_inline_paragraph(doc, [
            "若函数 ", "f", " 在 ", "[a,b]", " 上连续，且 ",
            r"f(a) \cdot f(b) < 0", "，则存在零点。"
        ])

    Returns:
        创建的 Paragraph 对象
    """
    from docx.shared import Pt
    from docx.oxml.ns import qn

    p = doc.add_paragraph(style=style)

    for seg in segments:
        if is_latex(seg):
            # LaTeX → 行内公式
            omml = latex_to_omml(seg)
            p._element.append(omml)
        else:
            # 普通文字
            run = p.add_run(seg)
            if font_size:
                run.font.size = Pt(font_size)
            if font_name:
                run.font.name = font_name

    return p


def render_inline_document(
    sections: list,
    output_path: str,
    title: str = None,
    open_after: bool = True
):
    """
    生成段落式文档（适合定理、证明、笔记等）。

    Args:
        sections: 列表，每项为：
                  - {"heading": "标题", "level": 1}
                  - {"text": [...]}  → 调用 add_inline_paragraph
                  - {"blank": True} → 空行
        output_path: 输出 .docx 路径
        title: 文档总标题（None 则不加）
        open_after: 是否自动打开

    Example:
        render_inline_document([
            {"heading": "零点存在定理", "level": 2},
            {"text": ["若函数 ", "f", " 在 ", "[a,b]", " 上连续..."]},
            {"blank": True},
            {"heading": "证明", "level": 3},
            {"text": ["令 ", r"g(x)=f(x)-\lambda", "，则..."]},
        ], "theorem.docx")
    """
    doc = Document()
    
    if title:
        doc.add_heading(title, 0)

    for sec in sections:
        if "heading" in sec:
            doc.add_heading(sec["heading"], level=sec.get("level", 1))
        elif "blank" in sec:
            doc.add_paragraph()
        elif "text" in sec:
            add_inline_paragraph(doc, sec["text"])

    doc.save(output_path)
    
    if open_after:
        import os
        os.startfile(output_path)

    return output_path


def render_latex_to_word(
    formulas: list,
    output_path: str,
    title: str = "公式文档",
    open_after: bool = True
):
    """
    将 LaTeX 公式列表渲染到 Word 文档。

    Args:
        formulas: [(latex_str, description), ...] 或 [latex_str, ...]
        output_path: 输出 .docx 路径
        title: 文档标题
        open_after: 是否自动打开生成的文件
    """
    doc = Document()
    doc.add_heading(title, 0)

    for i, item in enumerate(formulas):
        if isinstance(item, tuple):
            latex, desc = item
        else:
            latex, desc = item, ""

        p = doc.add_paragraph()
        
        if desc:
            run = p.add_run(f"[{i+1}] {desc}: ")
        else:
            run = p.add_run(f"[{i+1}] ")

        try:
            omml = latex_to_omml(latex)
            p._element.append(omml)
        except Exception as e:
            run.add_run(f" ✗ 转换失败: {str(e)[:60]}")

    doc.save(output_path)
    
    if open_after:
        import os
        os.startfile(output_path)
    
    return output_path


def render_latex_string(latex: str, output_path: str, open_after: bool = True):
    """渲染单个 LaTeX 字符串到 Word 文档"""
    formulas = [(line.strip(), "") for line in latex.split("\n") if line.strip()]
    return render_latex_to_word(formulas, output_path, open_after=open_after)


def read_latex_file(filepath: str) -> list:
    """从文件读取 LaTeX 公式列表"""
    formulas = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if '|' in line:
                latex, desc = line.split('|', 1)
                formulas.append((latex.strip(), desc.strip()))
            else:
                formulas.append((line, ""))
    return formulas


# CLI 入口
if __name__ == "__main__":
    sys.stdout.reconfigure(encoding='utf-8')
    
    if len(sys.argv) < 2:
        # 演示模式
        print("LaTeX → Word 渲染器")
        print("用法: python latex_word_renderer.py input.txt output.docx")
        print()
        print("运行演示...")
        
        demo_formulas = [
            (r"\frac{a}{b} + \frac{c}{d} = \frac{ad+bc}{bd}", "分式运算"),
            (r"x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}", "一元二次方程求根公式"),
            (r"\int_0^\infty e^{-x^2}dx = \frac{\sqrt{\pi}}{2}", "高斯积分"),
            (r"\lim_{x\to 0} \frac{\sin x}{x} = 1", "重要极限"),
            (r"\sum_{n=1}^\infty \frac{1}{n^2} = \frac{\pi^2}{6}", "巴塞尔问题"),
            (r"\begin{pmatrix} a_{11} & a_{12} \\ a_{21} & a_{22} \end{pmatrix}", "2×2 矩阵"),
            (r"\binom{n}{k} = \frac{n!}{k!(n-k)!}", "二项式系数"),
            (r"\vec{F} = m\vec{a}", "牛顿第二定律"),
            (r"\frac{\partial^2 u}{\partial x^2} + \frac{\partial^2 u}{\partial y^2} = 0", "拉普拉斯方程"),
            (r"E = mc^2", "质能方程"),
        ]
        
        output = r"C:\Users\周嘉玮\cow\tmp\latex_demo.docx"
        render_latex_to_word(demo_formulas, output, title="LaTeX 公式渲染演示")
        print(f"演示文档: {output}")
    
    elif len(sys.argv) == 2:
        # 渲染文件中的公式
        input_file = sys.argv[1]
        output = input_file.rsplit('.', 1)[0] + '.docx'
        formulas = read_latex_file(input_file)
        render_latex_to_word(formulas, output)
        print(f"已生成: {output}")
    
    else:
        input_file = sys.argv[1]
        output = sys.argv[2]
        formulas = read_latex_file(input_file)
        render_latex_to_word(formulas, output)
        print(f"已生成: {output}")
