---
name: latex-to-word
description: Render LaTeX math formulas as native Word equations in .docx files. Use when the user needs to create Word documents containing mathematical formulas from LaTeX source, including fractions, integrals, sums, limits, matrices, vectors, partial derivatives, and binomial coefficients. Also use for batch converting LaTeX formula lists to Word format, or generating formula-heavy documents like exam papers and lecture notes.
metadata:
  requires:
    bins: ["C:\\Users\\周嘉玮\\cow\\tools\\python32\\python.exe"]
---

# LaTeX to Word

Render LaTeX math formulas as **native Word equations** (OMML) in .docx files — fully editable, high-quality, no screenshots or MathType.

## Architecture

```
LaTeX → latex2mathml → MathML → MML2OMML.xsl (Microsoft official) → OMML → python-docx → .docx
```

## Prerequisites

- Python with `latex2mathml`, `python-docx`, `lxml` installed
- Microsoft Office installed (for `MML2OMML.XSL` at `C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL`)

## Usage

The renderer script is at `<base_dir>/scripts/renderer.py`. Use the python binary specified in requirements.

### Python API

#### 基础：公式列表渲染

```python
import sys
sys.path.insert(0, '<base_dir>/scripts')
from renderer import render_latex_to_word

formulas = [
    (r"\frac{a}{b} + \frac{c}{d} = \frac{ad+bc}{bd}", "分式运算"),
    (r"x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}",       "求根公式"),
]
render_latex_to_word(formulas, "output.docx", title="公式文档")
```

#### 行内公式段落：文字 + 公式交替

```python
from docx import Document
from renderer import add_inline_paragraph

doc = Document()
add_inline_paragraph(doc, [
    "若函数 ", "f", " 在闭区间 ", "[a,b]", " 上连续，且 ",
    r"f(a) \cdot f(b) < 0", "，则至少存在一点 ",
    r"\xi \in (a,b)", "，使得 ", r"f(\xi) = 0", "。"
])
doc.save("theorem.docx")
```

每个 segment 自动判断：含 `\`, `^`, `_`, `{`, `}` 的视为 LaTeX 公式，其余为普通文字。

#### 结构化文档：标题 + 段落

```python
from renderer import render_inline_document

render_inline_document([
    {"heading": "零点存在定理", "level": 2},
    {"text": ["若函数 ", "f", " 在 ", "[a,b]", " 上连续..."]},
    {"blank": True},
    {"heading": "证明", "level": 3},
    {"text": ["令 ", r"g(x)=f(x)-\lambda", "，则..."]},
], "theorem.docx", title="中值定理讲义")
```

### CLI

```bash
# Batch from file (each line: latex|description)
python <base_dir>/scripts/renderer.py formulas.txt output.docx

# Demo mode (10 sample formulas)
python <base_dir>/scripts/renderer.py
```

### Input File Format

One formula per line. Optional description separated by `|`:

```
\frac{a}{b}|分式公式
\int_0^1 f(x)dx
E=mc^2|质能方程
```

## Supported Formula Types

| Type | Example LaTeX | Status |
|------|--------------|--------|
| Fractions | `\frac{a}{b}` | ✅ |
| Square roots | `\sqrt{x^2+y^2}` | ✅ |
| Integrals | `\int_0^\infty e^{-x^2}dx` | ✅ |
| Limits | `\lim_{x\to 0} \frac{\sin x}{x}` | ✅ |
| Sums | `\sum_{n=1}^\infty \frac{1}{n^2}` | ✅ |
| Matrices | `\begin{pmatrix} a & b \\ c & d \end{pmatrix}` | ✅ |
| Binomial coefficients | `\binom{n}{k}` | ✅ |
| Vectors | `\vec{F} = m\vec{a}` | ✅ |
| Partial derivatives | `\frac{\partial^2 u}{\partial x^2}` | ✅ |
| Superscripts/subscripts | `x^2`, `a_i` | ✅ |

### Public API

- `render_latex_to_word(formulas, output_path, title?, open_after?)` — 公式列表转 Word
- `add_inline_paragraph(doc, segments, style?, font_size?, font_name?)` — 文字+公式混合段落
- `render_inline_document(sections, output_path, title?, open_after?)` — 结构化文档（标题+段落）
- `render_latex_string(latex, output_path, open_after?)` — 单个 LaTeX 字符串转文档
- `read_latex_file(filepath)` — 解析公式文件
- `latex_to_omml(latex)` — 底层：LaTeX → OMML XML 元素

## Limitations

- Requires Office 2010+ for the XSL transformer
- Extremely complex LaTeX (custom macros, deeply nested structures) may not convert perfectly
- All formulas rendered inline — adjust MathML `display` attribute for display-style if needed
- Depends on Word's default Cambria Math font
